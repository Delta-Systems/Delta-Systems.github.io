module.exports = {

  stylePrefix: 'cv-',

  // Coming soon
  rulers: false,

  /*
   * append scripts in head of iframe before renderBody content
   * need to manually maintain the same scripts in cms's render template
  */
  scripts: []

};
