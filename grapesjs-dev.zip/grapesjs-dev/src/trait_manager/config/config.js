module.exports = {
  stylePrefix: 'trt-',
  labelContainer: 'Component settings',
};
