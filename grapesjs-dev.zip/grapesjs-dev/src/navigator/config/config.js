module.exports = {
  stylePrefix: 'nv-',
  sortable: 1,
  hidable: 1,
  hideTextnode: 1,
  containerId: 'navigator',
  itemClass: 'item',
  itemsClass: 'items',
};
