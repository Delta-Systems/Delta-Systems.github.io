var Backbone = require('backbone');

module.exports = Backbone.View.extend({});
