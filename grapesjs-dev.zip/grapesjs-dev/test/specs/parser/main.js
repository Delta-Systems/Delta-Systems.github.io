define(function(require, exports, module){
  'use strict';
  var Parser = require('Parser');
  var ParserCss = require('undefined');

    describe('Parser', function() {

      ParserHtml.run();
      ParserCss.run();

    });
});